# Builder task messages

The shape of one message to the builder agent. A branching task hands the builder
one component; a linear task hands over the whole plan. Either way, exploration
happens inside the turn.

## Anatomy

1. **Goal** — what must be true when done. Outcome, not procedure.
2. **Location** — page/section by on-form name.
3. **Inputs** — known (exact `context.inputs.…` paths from the schema slice) or
   to-discover (the builder learns these in-turn via `interact`). The known set is
   a seed to explore in breadth and/or depth, not a closed list — confirm each
   field's real shape live (depth), and probe for what the seed couldn't show, like
   reveals and their type (breadth).
4. **Status skeleton** — compact whole-build progress block so the builder knows
   where this task sits. Never the full plan, other components' details, or history.
5. **Conventions** — inputs via `{{context.inputs.…}}` never literals; `run_if`
   gating stated as data; node naming per the naming reference; the pattern contract
   if the component matched one.

## Rules

- Goal, not clicks. Never selectors, execution types, or node structure.
- State required actions directly. Use conditional phrasing only when evaluating
  that condition is itself part of the workflow behavior.
- A branching task dispatches one component with phases explore, build, prove; a
  linear task dispatches the whole plan in one message. Either way, phases may
  complete in one or more builder turns.
- Text only — the builder reads the page directly, so a screenshot adds nothing.
- Exact paths verbatim; a paraphrased path wires the wrong variable silently.
- Default completion: a debug execution succeeds. Spell out extras only for unusual
  components.

## Linear: one message, the whole plan

The task carries the plan whole — goal, ordered steps, the data map, every
variable already named with its shape. Status comes from the turn's report rather
than a per-task count: steps attempted, completed, and any that stalled with why,
folded into the skeleton after each turn.

## The schema block

A task that registers or extends `input_schema` restates the conventions in the
message (they live in `input-schema.md`) — a slice composed without them looks right
and fails when a payload is rejected at run start. Register new inputs beneath the
consuming component's dotted path. The conventions:

> **Schema conventions:** scalar leaves a `run_if IS_NOT_NULL` can skip are typed
> `["<type>","null"]` — null is the absence value, empty string never is. Every key
> appears in its object's `required`, at every level. `additionalProperties: false`
> on every object. Anchored `pattern` on formatted strings, matching your own
> examples. Never `required` inside a `then` — narrow types in `then.properties`
> instead. Every object using `contains` carries a sibling `"type": "array"`.

A component whose shape genuinely wants something else — a leaf that must never be
null, an object that legitimately takes unknown keys — diverges deliberately and
**says so in the task message**. A slice that diverges silently, because nobody
stated the default, is the failure this prevents.

## Worked example: branching track

Component `cardiac_status.cardiac_assessment`:

> **Goal:** Fill the Cardiac Assessment findings checklist and every field each
> selected finding reveals. Done: `findings` matches the on-form selections; each
> revealed detail field is filled; nothing left revealed-but-empty.
>
> **Location:** Cardiac Status page, Cardiac Assessment section.
>
> **Inputs:**
> - `context.inputs.cardiac_status.cardiac_assessment.findings` (array, known)
> - `context.inputs.cardiac_status.cardiac_assessment.abnormal_pulses_type`,
>   `.abnormal_pulses_location` — revealed when `findings` contains
>   `"Abnormal pulses:"` (paths known; to-discover: whether the location field is
>   free text or a fixed-option select — confirm live)
> - `context.inputs.cardiac_status.cardiac_assessment.chest_pain.quality` —
>   revealed when `findings` contains `"Chest pain:"` (path and enum both known)
>
> **Status:** page 6 of 14 (Cardiac Status) · 2 of 9 components on this page ·
> 41 of 63 overall.
>
> **Conventions:** inputs via `{{context.inputs...}}`, never literals. `run_if`
> gates every reveal-dependent node on `findings` per the schema's `contains` rule.
> Node names: `cardiac_status.cardiac_assessment.findings — check findings`,
> `cardiac_status.cardiac_assessment.abnormal_pulses_type — enter type`.

## Worked example: resume — position the browser

A fresh browser at a deep frontier. This turn just gets there:

> **Resume — position the browser.** Fresh browser, not logged in. Frontier is the New
> Wound subform on the Integumentary Status page (~page 9).
>
> Use interact to log in with the vault credentials, open a fresh NURSE RECERTIFICATION
> eDoc — office `Test`, any test patient — and use the form's Page navigation to jump to
> Integumentary Status. Stop there; build and save nothing this turn.

## Worked example: linear track, whole plan

Benefits claim lookup, one message for the full plan:

> **Goal:** Look up a benefits claim by ID and record the caller's callback note.
>
> **Steps:**
> 1. Navigate to the benefits claim lookup page.
> 2. Enter the claim ID into the claim number field — register a new input
>    variable `context.inputs.claim_id` (string, example `CLM-2049123`).
> 3. Click search.
> 4. If no claim is found, click save-as-not-found and end; otherwise continue.
> 5. Enter the caller's phone number — register `context.inputs.caller_phone`
>    (string, example `312-555-0142`).
> 6. Set the follow-up note to "Callback confirmed for " followed by the existing
>    `context.inputs.caller_phone` — don't register a second phone variable.
> 7. Click save.
> 8. Extract the claim status and confirmation number, the standard way.

A turn may get through every step, or only some — either way the report names
what it reached and, for anything short of the goal, why.
